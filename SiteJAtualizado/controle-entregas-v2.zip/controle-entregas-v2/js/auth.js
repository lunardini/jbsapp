// ============================================================================
// auth.js — usado apenas em index.html (a tela de login).
// Depois de autenticar, a navegação vai para buscar.html: o login sai da tela
// por completo, em vez de continuar montado atrás do conteúdo.
// ============================================================================
import {
  auth, signInWithEmailAndPassword, onAuthStateChanged, sendPasswordResetEmail,
} from "./firebase.js";
import { firebaseConfig } from "./config.js";
import { $, aviso, comCarregamento, mensagemDeErro } from "./ui.js";

const DESTINO = "buscar.html";

export function usuarioLogado() { return auth.currentUser; }

/** Objeto gravado junto de cada ocorrência/retenção. */
export function autor() {
  const u = auth.currentUser;
  if (!u) throw new Error("Sessão expirada. Entre novamente.");
  return { uid: u.uid, email: u.email, nome: u.displayName || u.email.split("@")[0] };
}

export function iniciarLogin() {
  if (firebaseConfig.apiKey.startsWith("COLE")) {
    aviso("Preencha as chaves do Firebase em js/config.js.", "erro", 15000);
  }

  const form = $("#form-login");
  const erro = $("#login-erro");

  // Quem já tem sessão aberta não vê o login: vai direto para o sistema.
  onAuthStateChanged(auth, (u) => {
    if (u) { location.replace(DESTINO); return; }
    $("#carregando")?.remove();
    $("#acesso").hidden = false;
    $("#login-email").focus();
  });

  form.addEventListener("submit", async (ev) => {
    ev.preventDefault();
    erro.textContent = "";
    await comCarregamento($("#btn-entrar"), "Entrando…", async () => {
      try {
        await signInWithEmailAndPassword(auth, $("#login-email").value.trim(), $("#login-senha").value);
        location.replace(DESTINO);
      } catch (e) {
        erro.textContent = mensagemDeErro(e);
        $("#login-senha").select();
      }
    });
  });

  $("#btn-esqueci").addEventListener("click", async () => {
    const email = $("#login-email").value.trim();
    if (!email) { erro.textContent = "Digite seu e-mail acima para receber o link."; return; }
    try {
      await sendPasswordResetEmail(auth, email);
      aviso("Link de redefinição enviado. Confira a caixa de entrada.", "ok");
    } catch (e) { erro.textContent = mensagemDeErro(e); }
  });
}
